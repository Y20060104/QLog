package bq.def;
/*
 * Copyright (C) 2025 Tencent.
 * BQLOG is licensed under the Apache License, Version 2.0.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

public enum log_arg_type_enum {
	unsupported_type,
    null_type,
    pointer_type,
    bool_type,
    char_type,
    char16_type,
    char32_type,
    int8_type,
    uint8_type,
    int16_type,
    uint16_type,
    int32_type,
    uint32_type,
    int64_type,
    uint64_type,
    float_type,
    double_type,
    string_utf8_type,
    string_utf16_type,
    string_utf32_type,
    string_utf_mixed_type
}
